// Servidor do VFR: entrega o app e faz a ponte com a API da Anthropic.
// A chave fica só aqui, nunca vai para o navegador.
import 'dotenv/config';
import express from 'express';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const KEY = process.env.ANTHROPIC_API_KEY || '';
const MODELS = {
  quick: process.env.VFR_MODEL_QUICK || 'claude-haiku-4-5-20251001',
  default: process.env.VFR_MODEL_DEFAULT || 'claude-sonnet-5-5',
};

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '64kb' }));

// limite simples por IP: 40 chamadas por minuto
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60_000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 40;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, ai: Boolean(KEY) }));

app.post('/api/ai', async (req, res) => {
  if (!KEY) return res.status(503).json({ error: 'ANTHROPIC_API_KEY não configurada' });
  if (limited(req.ip)) return res.status(429).json({ error: 'muitas chamadas, tente em instantes' });
  const { prompt, tier } = req.body || {};
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > 14_000) {
    return res.status(400).json({ error: 'prompt inválido' });
  }
  const model = MODELS[tier === 'default' ? 'default' : 'quick'];
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model,
        max_tokens: tier === 'default' ? 1800 : 600,
        system: 'Você responde sempre em JSON válido, sem texto fora do JSON, exatamente no formato pedido.',
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    if (!r.ok) {
      console.error('Anthropic respondeu', r.status, (await r.text()).slice(0, 300));
      return res.status(502).json({ error: 'falha na IA' });
    }
    const j = await r.json();
    const text = (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    res.json({ text });
  } catch (e) {
    console.error('Erro chamando a IA:', e.message);
    res.status(502).json({ error: 'falha na IA' });
  }
});

// O app é um fragmento HTML (título, estilo e script); aqui ele ganha o esqueleto da página.
app.get('/', async (_req, res) => {
  const frag = await readFile(path.join(__dirname, 'app', 'index.html'), 'utf8');
  res.type('html').send(
    '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">' +
    '<meta name="color-scheme" content="dark light"></head><body>' + frag + '</body></html>'
  );
});

app.listen(PORT, () => {
  console.log(`VFR no ar: http://localhost:${PORT}  (IA ${KEY ? 'ligada' : 'desligada: defina ANTHROPIC_API_KEY'})`);
});
