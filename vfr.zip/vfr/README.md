# VFR

Esquadrão de robôs de investimento. Em vez de um formulário, a pessoa conversa com o **Copiloto** (uma IA). Ele lê o texto livre, preenche vários campos de uma vez e só pergunta o que faltou. No fim, **seis robôs** com personalidades diferentes são convocados, do mais cauteloso ao mais ousado, e os que não cabem na vida da pessoa ficam **trancados**.

Esta é a fase 1: só front-end e IA de conversa. **Não há motor de cálculo** (nem Markowitz, nem otimização). Os robôs são personagens fictícios que representam perfis.

## Rodar

```bash
npm install
cp .env.example .env     # coloque sua ANTHROPIC_API_KEY
npm start                # http://localhost:3000
```

Sem a chave, o app funciona só com botões e a leitura final usa textos padrão (a barra do topo mostra "IA desligada").

## Como é feito

| Parte | Onde | O que faz |
|---|---|---|
| App inteiro | `app/index.html` | Interface, perguntas, robôs em SVG, travas, chamadas à IA. Um arquivo só, sem build. |
| Servidor | `server.js` | Serve o app e expõe `POST /api/ai` (ponte com a API da Anthropic) e `GET /api/health`. A chave nunca vai para o navegador. |
| Cobertura CVM | `docs/perguntas-cvm.md` | Tabela pergunta → frente da Resolução CVM 30 → efeito no app. |

### Fluxo
1. **Abertura livre:** a pessoa conta quem é. A IA devolve JSON com os campos que entendeu (`fields`) e uma resposta.
2. **Perguntas que faltam:** cartões de resposta (teclas 1 a 9) e texto livre a qualquer momento. A IA também responde dúvidas ("o que é Selic?") e volta à pergunta.
3. **Dossiê:** três medidores (objetivos, situação financeira, conhecimento). Tocar numa resposta permite mudá-la.
4. **Convocação:** as travas (regras fixas em `caps()`) decidem quais robôs ficam liberados. A IA lê o dossiê e escreve, para cada robô, o quanto combina, o porquê e uma dica. Sem IA, entram textos padrão.

### Os seis robôs
`TATU-7` (Escudeiro Blindado) · `PÊNDULO` (Mestre do Ritmo) · `MAESTRO` (Equilibrista) · `FÊNIX` (Construtor de Longo Prazo) · `TURBO-9` (Piloto de Prova) · `COMETA-0` (Explorador de Fronteira)

Para editar nomes, textos e travas, veja `ROBOTS`, `FIELDS` e `caps()` em `app/index.html`.

## Avisos
- Protótipo de demonstração. Nada aqui é recomendação de investimento.
- Antes de qualquer lançamento, valide o enquadramento regulatório (suitability, quem pode recomendar) com um jurídico. Veja as lacunas em `docs/perguntas-cvm.md`.
- O app guarda as respostas só na memória da página. Nada é salvo no servidor.

## Publicar no GitHub

```bash
gh repo create vfr --private --source=. --push
```
