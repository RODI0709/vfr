# Perguntas do briefing e cobertura da Resolução CVM 30

A Resolução CVM 30 (art. 3) manda verificar a adequação ao perfil do cliente em três frentes: **objetivos**, **situação financeira** e **conhecimento**. O briefing do VFR pergunta cada ponto de forma conversada. Esta tabela mostra o que cada pergunta cobre e o que ela faz no app.

> Estrutura inspirada na norma. Não substitui validação jurídica. A classificação oficial de perfil (art. 4), a política de suitability e a reclassificação periódica (art. 9) ainda não existem neste protótipo.

| # | Pergunta (chave) | Frente | Item do art. 3 | Efeito no app |
|---|---|---|---|---|
| 1 | Finalidade (`goal`) | Objetivos | §1º, finalidade | Contexto para a IA |
| 2 | Prazo (`horizon`) | Objetivos | §1º, prazo pretendido | **Trava** robôs por prazo |
| 3 | Estabilidade da renda (`estab`) | Situação financeira | §2º, receitas regulares | Contexto para a IA |
| 4 | Renda mensal (`renda`) | Situação financeira | §2º, receitas regulares | Contexto para a IA |
| 5 | Reserva de emergência (`reserva`) | Situação financeira | §2º, patrimônio e necessidades | **Trava** |
| 6 | Dívidas caras (`divida`) | Situação financeira | §2º, situação financeira | **Trava** |
| 7 | Uso do dinheiro em 12 meses (`need`) | Situação financeira | §2º, necessidades futuras de recursos | **Trava** |
| 8 | Patrimônio (`patri`) | Situação financeira | §2º, valor do patrimônio | Contexto para a IA |
| 9 | Composição do patrimônio (`comp`) | Situação financeira | §2º, ativos que compõem o patrimônio | Contexto para a IA |
| 10 | Reação a perdas (`risk`) | Objetivos | §1º, preferência quanto a risco | **Trava** |
| 11 | Frase de preferência de risco (`prefer`) | Objetivos | §1º, preferência quanto a risco | **Trava** |
| 12 | Restrições (`restr`) | Objetivos | §1º | **Trava** (cripto, só renda fixa) |
| 13 | Produtos que conhece (`known`) | Conhecimento | §3º, tipos de produtos | **Trava** por experiência |
| 14 | Frequência (`freq`) | Conhecimento | §3º, frequência das operações | Contexto para a IA |
| 15 | Há quanto tempo investe (`tempo`) | Conhecimento | §3º, período | Contexto para a IA |
| 16 | Formação e trabalho (`forma`) | Conhecimento | §3º, formação e experiência profissional | Contexto para a IA |

## Lacunas conhecidas (próximos passos)
- **Volume das operações anteriores** (§3º) ainda não é perguntado.
- **Custos diretos e indiretos** (§5º) só entram quando houver produtos reais.
- **Pessoa jurídica** (§4º) não é tratada.
- **Classificação formal em categorias de perfil** e **reclassificação periódica** (arts. 4 e 9).
- Quem pode legalmente recomendar: distribuidores e consultores de valores mobiliários (ver Resolução CVM 19 para consultores). Definir o enquadramento jurídico da plataforma antes de qualquer lançamento.

## Travas dos robôs (regras fixas, sem cálculo)
Cada resposta pode limitar até qual robô (1 a 6) fica liberado. Vale o limite mais baixo. As regras estão na função `caps()` em `app/index.html`.

| Resposta | Libera até o robô |
|---|---|
| Dívida cara pesando | 1 |
| Reserva menor que 1 mês | 1 |
| Reserva de 1 a 3 meses | 2 |
| Vai precisar de quase tudo em 12 meses | 1 |
| Vai precisar de parte em 12 meses | 3 |
| Prazo menor que 1 ano / 1 a 3 / 3 a 5 / 5 a 10 anos | 1 / 2 / 3 / 5 |
| Tira tudo quando a conta cai / fica aflito | 2 / 4 |
| Prefere nunca ver a conta cair / aceita oscilar pouco | 2 / 4 |
| Sem cripto / só renda fixa | 5 / 2 |
| Não conhece renda variável / só fundos, CDB e Tesouro | 3 / 5 |

Fonte da norma: [Resolução CVM 30 (Legisweb)](https://www.legisweb.com.br/legislacao/?id=414074).
